npm install colors
npm install vk-io
python 1